import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ShoppingBag, Tag, Star, Search, Filter } from 'lucide-react';

const products = [
  {
    id: '1',
    title: 'React Component Library',
    description: 'A collection of reusable React components with TypeScript support',
    price: 49.99,
    rating: 4.8,
    sales: 234,
    author: 'John Doe',
    image: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=300'
  },
  {
    id: '2',
    title: 'Next.js Starter Template',
    description: 'Production-ready Next.js template with authentication and database setup',
    price: 79.99,
    rating: 4.9,
    sales: 156,
    author: 'Sarah Smith',
    image: 'https://images.unsplash.com/photo-1551650975-87deedd944c3?w=300'
  },
  {
    id: '3',
    title: 'UI/UX Design System',
    description: 'Complete design system with Figma files and code implementation',
    price: 129.99,
    rating: 4.7,
    sales: 89,
    author: 'Michael Chen',
    image: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?w=300'
  }
];

export function Marketplace() {
  return (
    <div className="space-y-8">
      <section className="text-center">
        <h1 className="text-4xl font-bold">
          <span className="gradient-text">Developer Marketplace</span>
        </h1>
        <p className="mt-4 text-lg text-muted-foreground">
          Discover and sell high-quality developer resources
        </p>
        <Button className="btn-gradient mt-6">List Your Product</Button>
      </section>

      <div className="flex items-center space-x-4 mb-8">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input className="pl-10" placeholder="Search products..." />
        </div>
        <Button variant="outline" className="flex items-center space-x-2">
          <Filter className="h-4 w-4" />
          <span>Filters</span>
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {products.map((product) => (
          <Card key={product.id} className="overflow-hidden hover-card-effect">
            <img
              src={product.image}
              alt={product.title}
              className="h-48 w-full object-cover"
            />
            <div className="p-6">
              <h3 className="text-xl font-bold">{product.title}</h3>
              <p className="mt-2 text-muted-foreground">{product.description}</p>
              <p className="mt-2 text-sm text-muted-foreground">By {product.author}</p>
              <div className="mt-4 flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Star className="h-4 w-4 text-yellow-400" />
                  <span>{product.rating}</span>
                  <span className="text-muted-foreground">({product.sales} sales)</span>
                </div>
                <span className="text-xl font-bold">${product.price}</span>
              </div>
              <div className="mt-4 flex space-x-2">
                <Button className="flex-1">Preview</Button>
                <Button variant="outline" className="flex-1">Add to Cart</Button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}