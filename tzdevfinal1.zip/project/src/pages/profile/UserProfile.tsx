import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { UserProfile } from '@/types/user';
import { PostCard } from '@/components/posts/PostCard';
import { 
  User, Settings, Bookmark, Archive, 
  PenTool, BookOpen, Users, Map 
} from 'lucide-react';

interface ProfileTabsProps {
  user: UserProfile;
}

export function ProfileTabs({ user }: ProfileTabsProps) {
  return (
    <Tabs defaultValue="posts" className="w-full">
      <TabsList className="grid w-full grid-cols-4 lg:grid-cols-8">
        <TabsTrigger value="posts">Posts</TabsTrigger>
        <TabsTrigger value="articles">Articles</TabsTrigger>
        <TabsTrigger value="blogs">Blogs</TabsTrigger>
        <TabsTrigger value="techstack">Tech Stack</TabsTrigger>
        <TabsTrigger value="roadmap">Roadmap</TabsTrigger>
        <TabsTrigger value="bookmarks">Bookmarks</TabsTrigger>
        <TabsTrigger value="archive">Archive</TabsTrigger>
        <TabsTrigger value="settings">Settings</TabsTrigger>
      </TabsList>

      <div className="mt-6">
        <TabsContent value="posts">
          <div className="space-y-6">
            {/* Posts content */}
          </div>
        </TabsContent>

        <TabsContent value="techstack">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {user.techStack.map((tech) => (
              <Card key={tech.name} className="p-4">
                <div className="flex items-center space-x-3">
                  <img src={tech.icon} alt={tech.name} className="h-8 w-8" />
                  <div>
                    <h3 className="font-semibold">{tech.name}</h3>
                    <p className="text-sm text-muted-foreground">{tech.experience}</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Add other tab contents */}
      </div>
    </Tabs>
  );
}