import { HeroSection } from '@/components/HeroSection';
import { InfiniteScroll } from '@/components/InfiniteScroll';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowRight, Users, BookOpen, MessageSquare } from 'lucide-react';

export function Home() {
  return (
    <div className="space-y-12">
      <HeroSection />

      <section className="py-12">
        <h2 className="text-3xl font-bold tracking-tight">Why Join TzDevs?</h2>
        <div className="mt-8 grid gap-6 md:grid-cols-3">
          <Card className="p-6">
            <Users className="h-12 w-12 text-primary" />
            <h3 className="mt-4 text-xl font-semibold">Connect</h3>
            <p className="mt-2 text-muted-foreground">
              Network with developers across Tanzania and build meaningful connections.
            </p>
          </Card>
          <Card className="p-6">
            <BookOpen className="h-12 w-12 text-primary" />
            <h3 className="mt-4 text-xl font-semibold">Learn</h3>
            <p className="mt-2 text-muted-foreground">
              Access resources, articles, and learn from experienced developers.
            </p>
          </Card>
          <Card className="p-6">
            <MessageSquare className="h-12 w-12 text-primary" />
            <h3 className="mt-4 text-xl font-semibold">Collaborate</h3>
            <p className="mt-2 text-muted-foreground">
              Work on exciting projects and grow your skills with peers.
            </p>
          </Card>
        </div>
      </section>

      <section className="py-12">
        <div className="flex items-center justify-between">
          <h2 className="text-3xl font-bold tracking-tight">Latest Updates</h2>
          <Button variant="ghost" className="gap-2">
            View All
            <ArrowRight className="h-4 w-4" />
          </Button>
        </div>
        <div className="mt-8">
          <InfiniteScroll />
        </div>
      </section>
    </div>
  );
}