import { ProjectCard } from '@/components/cards/ProjectCard';
import { Button } from '@/components/ui/button';

const projects = [
  {
    title: 'TzDevs Platform',
    description: 'The main platform for Tanzania\'s developer community',
    stars: 24,
    forks: 8,
  },
  {
    title: 'Community API',
    description: 'Open source API for developer resources in Tanzania',
    stars: 16,
    forks: 5,
  },
  // Add more projects as needed
];

export function Projects() {
  return (
    <div className="space-y-8">
      <section className="text-center">
        <h1 className="text-4xl font-bold">
          <span className="gradient-text">Community Projects</span>
        </h1>
        <p className="mt-4 text-lg text-muted-foreground">
          Discover and contribute to projects built by the TzDevs community.
        </p>
        <Button className="btn-gradient mt-6">Submit a Project</Button>
      </section>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {projects.map((project, index) => (
          <ProjectCard key={index} {...project} />
        ))}
      </div>
    </div>
  );
}