import { FeatureCard } from '@/components/cards/FeatureCard';
import { BookOpen, Video, Code, GraduationCap, FileText, Users } from 'lucide-react';

const resources = [
  {
    icon: BookOpen,
    title: "Documentation",
    description: "Comprehensive guides and documentation for various technologies"
  },
  {
    icon: Video,
    title: "Video Tutorials",
    description: "Learn through video content created by community members"
  },
  {
    icon: Code,
    title: "Code Examples",
    description: "Real-world code examples and best practices"
  },
  {
    icon: GraduationCap,
    title: "Learning Paths",
    description: "Structured learning paths for different technologies"
  },
  {
    icon: FileText,
    title: "Articles",
    description: "Technical articles and tutorials from the community"
  },
  {
    icon: Users,
    title: "Mentorship",
    description: "Connect with experienced developers for guidance"
  }
];

export function Resources() {
  return (
    <div className="space-y-8">
      <section className="text-center">
        <h1 className="text-4xl font-bold">
          <span className="gradient-text">Learning Resources</span>
        </h1>
        <p className="mt-4 text-lg text-muted-foreground">
          Curated resources to help you grow as a developer
        </p>
      </section>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {resources.map((resource, index) => (
          <FeatureCard key={index} {...resource} />
        ))}
      </div>
    </div>
  );
}