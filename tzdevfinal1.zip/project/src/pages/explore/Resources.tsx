import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Youtube, Globe, BookOpen, Map } from 'lucide-react';

const resources = [
  {
    title: 'YouTube Channels',
    icon: Youtube,
    items: [
      { name: 'Traversy Media', url: 'https://youtube.com/traversymedia' },
      { name: 'Fireship', url: 'https://youtube.com/fireship' }
    ]
  },
  {
    title: 'Websites',
    icon: Globe,
    items: [
      { name: 'MDN Web Docs', url: 'https://developer.mozilla.org' },
      { name: 'Dev.to', url: 'https://dev.to' }
    ]
  },
  {
    title: 'Learning Paths',
    icon: Map,
    items: [
      { name: 'Frontend Development', url: '/roadmaps/frontend' },
      { name: 'Backend Development', url: '/roadmaps/backend' }
    ]
  }
];

export function ExploreResources() {
  return (
    <div className="space-y-8">
      <section className="text-center">
        <h1 className="text-4xl font-bold">
          <span className="gradient-text">Developer Resources</span>
        </h1>
        <p className="mt-4 text-lg text-muted-foreground">
          Curated resources to help you grow as a developer
        </p>
      </section>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {resources.map((section) => (
          <Card key={section.title} className="p-6">
            <div className="flex items-center space-x-3">
              <section.icon className="h-6 w-6 text-primary" />
              <h2 className="text-xl font-semibold">{section.title}</h2>
            </div>
            <div className="mt-4 space-y-3">
              {section.items.map((item) => (
                <a
                  key={item.name}
                  href={item.url}
                  className="block rounded-lg border p-3 hover:bg-accent"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  {item.name}
                </a>
              ))}
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}