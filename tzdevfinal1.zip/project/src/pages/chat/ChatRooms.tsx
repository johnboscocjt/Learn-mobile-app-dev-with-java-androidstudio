import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar } from '@/components/ui/avatar';
import { MessageSquare, Users, Search, Send, Plus } from 'lucide-react';

interface Message {
  id: string;
  content: string;
  sender: {
    name: string;
    avatar: string;
  };
  timestamp: string;
}

interface ChatRoom {
  id: string;
  name: string;
  lastMessage: string;
  unreadCount: number;
  participants: number;
}

const chatRooms: ChatRoom[] = [
  {
    id: '1',
    name: 'Frontend Developers',
    lastMessage: 'Anyone using the new React hooks?',
    unreadCount: 3,
    participants: 128
  },
  {
    id: '2',
    name: 'Backend Developers',
    lastMessage: 'Best practices for API security?',
    unreadCount: 0,
    participants: 95
  },
  {
    id: '3',
    name: 'UI/UX Discussion',
    lastMessage: 'Thoughts on the latest design trends?',
    unreadCount: 5,
    participants: 76
  }
];

const messages: Message[] = [
  {
    id: '1',
    content: 'Has anyone tried the new Vite 5.0?',
    sender: {
      name: 'John Doe',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100'
    },
    timestamp: '2:30 PM'
  },
  {
    id: '2',
    content: 'Yes, the build speed is amazing!',
    sender: {
      name: 'Sarah Smith',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100'
    },
    timestamp: '2:32 PM'
  }
];

export function ChatRooms() {
  const [selectedRoom, setSelectedRoom] = useState<string | null>(null);
  const [messageInput, setMessageInput] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  const handleSendMessage = () => {
    if (messageInput.trim()) {
      // Add message sending logic here
      setMessageInput('');
    }
  };

  return (
    <div className="container mx-auto p-6">
      <div className="grid gap-6 lg:grid-cols-[300px_1fr]">
        {/* Rooms List */}
        <Card className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold">Chat Rooms</h2>
            <Button size="icon" variant="ghost">
              <Plus className="h-4 w-4" />
            </Button>
          </div>
          <div className="flex items-center space-x-2 mb-4">
            <Input
              placeholder="Search rooms..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1"
            />
          </div>
          <div className="space-y-2">
            {chatRooms.map((room) => (
              <div
                key={room.id}
                className={`p-3 rounded-lg cursor-pointer transition-colors ${
                  selectedRoom === room.id ? 'bg-accent' : 'hover:bg-accent/50'
                }`}
                onClick={() => setSelectedRoom(room.id)}
              >
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold">{room.name}</h3>
                  {room.unreadCount > 0 && (
                    <span className="bg-primary text-primary-foreground text-xs px-2 py-1 rounded-full">
                      {room.unreadCount}
                    </span>
                  )}
                </div>
                <p className="text-sm text-muted-foreground mt-1">{room.lastMessage}</p>
                <div className="flex items-center text-xs text-muted-foreground mt-2">
                  <Users className="h-3 w-3 mr-1" />
                  {room.participants} participants
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Chat Area */}
        <Card className="p-4">
          <div className="flex flex-col h-[600px]">
            {selectedRoom ? (
              <>
                <div className="flex-1 overflow-y-auto space-y-4 mb-4">
                  {messages.map((message) => (
                    <div key={message.id} className="flex items-start space-x-3">
                      <Avatar>
                        <img src={message.sender.avatar} alt={message.sender.name} />
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <span className="font-semibold">{message.sender.name}</span>
                          <span className="text-xs text-muted-foreground">{message.timestamp}</span>
                        </div>
                        <p className="mt-1">{message.content}</p>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="flex items-center space-x-2">
                  <Input
                    placeholder="Type a message..."
                    value={messageInput}
                    onChange={(e) => setMessageInput(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  />
                  <Button size="icon" onClick={handleSendMessage}>
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
                <MessageSquare className="h-12 w-12 mb-4" />
                <p>Select a chat room to start messaging</p>
              </div>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}