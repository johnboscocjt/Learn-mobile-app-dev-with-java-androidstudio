import { Avatar } from '@/components/ui/avatar';
import { UserProfile } from '@/types/user';

interface UserAvatarProps {
  user: Pick<UserProfile, 'id' | 'avatar' | 'name'>;
  size?: 'sm' | 'md' | 'lg';
  linkDisabled?: boolean;
}

export function UserAvatar({ user, size = 'md', linkDisabled = false }: UserAvatarProps) {
  const sizeClasses = {
    sm: 'h-8 w-8',
    md: 'h-10 w-10',
    lg: 'h-12 w-12'
  };

  const avatar = (
    <Avatar className={`${sizeClasses[size]} transition-transform hover:scale-105`}>
      <img src={user.avatar} alt={user.name} />
    </Avatar>
  );

  return linkDisabled ? avatar : null;
}