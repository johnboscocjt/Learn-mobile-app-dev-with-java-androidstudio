import { Link } from 'react-router-dom';
import { UserAvatar } from '@/components/UserAvatar';
import { Post } from '@/types/post';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ThumbsUp, MessageSquare, Share2 } from 'lucide-react';

interface PostCardProps {
  post: Post;
}

export function PostCard({ post }: PostCardProps) {
  return (
    <Card className="p-6 hover-card-effect">
      <div className="flex items-start space-x-4">
        <Link to={`/profile/${post.author.id}`}>
          <UserAvatar 
            user={{
              id: post.author.id,
              avatar: post.author.avatar,
              name: post.author.name
            }}
            linkDisabled={true}
          />
        </Link>
        {/* ... rest of the component */}
      </div>
    </Card>
  );
}