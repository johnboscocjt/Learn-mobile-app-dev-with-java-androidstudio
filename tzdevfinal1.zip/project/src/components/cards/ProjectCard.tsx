import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Github, Star, GitFork } from 'lucide-react';

interface ProjectCardProps {
  title: string;
  description: string;
  stars: number;
  forks: number;
}

export function ProjectCard({ title, description, stars, forks }: ProjectCardProps) {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <Github className="h-6 w-6" />
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1">
              <Star className="h-4 w-4" />
              <span>{stars}</span>
            </div>
            <div className="flex items-center space-x-1">
              <GitFork className="h-4 w-4" />
              <span>{forks}</span>
            </div>
          </div>
        </div>
        <CardTitle>{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardFooter className="gap-2">
        <Button size="sm" variant="outline">View Project</Button>
        <Button size="sm">Contribute</Button>
      </CardFooter>
    </Card>
  );
}