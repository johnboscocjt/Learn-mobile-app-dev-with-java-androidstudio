import { useState, useEffect } from 'react';

interface FetchResponse<T> {
  data: T[];
  hasMore: boolean;
}

export function useFetchData<T>(url: string, page: number) {
  const [data, setData] = useState<T[]>([]);
  const [loading, setLoading] = useState(true);
  const [hasMore, setHasMore] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        // Simulated API call with pagination
        const response = await fetch(`${url}?page=${page}`);
        const json: FetchResponse<T> = await response.json();
        
        setData((prev) => [...prev, ...json.data]);
        setHasMore(json.hasMore);
      } catch (err) {
        setError(err instanceof Error ? err : new Error('An error occurred'));
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [url, page]);

  return { data, loading, hasMore, error };
}