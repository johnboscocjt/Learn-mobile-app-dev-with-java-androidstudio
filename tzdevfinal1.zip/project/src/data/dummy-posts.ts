import { Post } from '@/types/post';

export const dummyPosts: Post[] = [
  {
    id: '1',
    title: 'Introducing New Developer Tools',
    content: "We are excited to announce a new suite of developer tools that will help streamline your workflow...",
    author: {
      name: 'John Doe',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100'
    },
    date: '2 hours ago',
    likes: 42,
    comments: 12
  },
  {
    id: '2',
    title: 'Community Hackathon Results',
    content: 'The results are in from our latest community hackathon! Check out the amazing projects...',
    author: {
      name: 'Sarah Smith',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100'
    },
    date: '5 hours ago',
    likes: 38,
    comments: 15
  }
];