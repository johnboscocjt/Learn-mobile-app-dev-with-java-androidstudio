export interface TechStack {
  name: string;
  icon: string;
  experience: string;
}

export interface UserProfile {
  id: string;
  username: string;
  name: string;
  avatar: string;
  bio: string;
  techStack: TechStack[];
  followers: number;
  following: number;
  location: string;
  joinDate: string;
  socialLinks: {
    github?: string;
    twitter?: string;
    linkedin?: string;
    website?: string;
  };
}