import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { MessageSquare, ThumbsUp, Share2, Plus } from 'lucide-react';
import { Avatar } from '@/components/ui/avatar';

const posts = [
  {
    author: "John Doe",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100",
    date: "2 hours ago",
    title: "Looking for React Developers",
    content: "We're building a new e-commerce platform and looking for experienced React developers to join our team...",
    likes: 24,
    comments: 8
  },
  {
    author: "Sarah Smith",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100",
    date: "5 hours ago",
    title: "Upcoming Tech Meetup in Dar es Salaam",
    content: "Join us for an evening of networking and knowledge sharing. Topics include React, Node.js, and Cloud Computing...",
    likes: 32,
    comments: 12
  }
];

export function Billboard() {
  return (
    <div className="space-y-8">
      <section className="text-center">
        <h1 className="text-4xl font-bold">
          <span className="gradient-text">Community Billboard</span>
        </h1>
        <p className="mt-4 text-lg text-muted-foreground">
          Share and discover opportunities, events, and announcements
        </p>
        <Button className="btn-gradient mt-6">
          <Plus className="mr-2 h-4 w-4" />
          Create Post
        </Button>
      </section>

      <div className="space-y-6">
        {posts.map((post, index) => (
          <Card key={index} className="p-6 hover-card-effect">
            <div className="flex items-start space-x-4">
              <Avatar>
                <img src={post.avatar} alt={post.author} />
              </Avatar>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold">{post.author}</h3>
                  <span className="text-sm text-muted-foreground">{post.date}</span>
                </div>
                <h2 className="mt-2 text-xl font-bold">{post.title}</h2>
                <p className="mt-2 text-muted-foreground">{post.content}</p>
                <div className="mt-4 flex items-center space-x-4">
                  <Button variant="ghost" size="sm">
                    <ThumbsUp className="mr-2 h-4 w-4" />
                    {post.likes}
                  </Button>
                  <Button variant="ghost" size="sm">
                    <MessageSquare className="mr-2 h-4 w-4" />
                    {post.comments}
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Share2 className="mr-2 h-4 w-4" />
                    Share
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}