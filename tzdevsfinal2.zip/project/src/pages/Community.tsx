import { FeatureCard } from '@/components/cards/FeatureCard';
import { Button } from '@/components/ui/button';
import { Users, MessageSquare, Github, Award } from 'lucide-react';

const features = [
  {
    icon: Users,
    title: "Members Directory",
    description: "Connect with talented developers across Tanzania"
  },
  {
    icon: MessageSquare,
    title: "Discussion Forums",
    description: "Engage in technical discussions and knowledge sharing"
  },
  {
    icon: Github,
    title: "Open Source",
    description: "Contribute to community projects and initiatives"
  },
  {
    icon: Award,
    title: "Recognition",
    description: "Get recognized for your contributions to the community"
  }
];

export function Community() {
  return (
    <div className="space-y-8">
      <section className="text-center">
        <h1 className="text-4xl font-bold">
          <span className="gradient-text">TzDevs Community</span>
        </h1>
        <p className="mt-4 text-lg text-muted-foreground">
          Connect with developers across Tanzania, share knowledge, and grow together.
        </p>
        <Button className="btn-gradient mt-6">Join Our Community</Button>
      </section>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {features.map((feature, index) => (
          <FeatureCard key={index} {...feature} />
        ))}
      </div>
    </div>
  );
}