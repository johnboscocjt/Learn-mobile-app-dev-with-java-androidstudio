import { Link } from 'react-router-dom';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { UserAvatar } from '@/components/UserAvatar';
import { Trophy, Star, Github } from 'lucide-react';

const mvps = [
  {
    id: '1',
    name: 'John Doe',
    title: 'Frontend Developer',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100',
    contributions: 156,
    githubUrl: 'https://github.com/johndoe'
  },
  {
    id: '2',
    name: 'Sarah Smith',
    title: 'Full Stack Developer',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100',
    contributions: 142,
    githubUrl: 'https://github.com/sarahsmith'
  },
  {
    id: '3',
    name: 'Michael Chen',
    title: 'Backend Developer',
    avatar: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=100',
    contributions: 128,
    githubUrl: 'https://github.com/michaelchen'
  }
];

export function MVP() {
  return (
    <div className="space-y-8">
      <section className="text-center">
        <h1 className="text-4xl font-bold">
          <span className="gradient-text">Most Valuable Contributors</span>
        </h1>
        <p className="mt-4 text-lg text-muted-foreground">
          Recognizing our community's outstanding contributors
        </p>
      </section>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {mvps.map((mvp) => (
          <Card key={mvp.id} className="p-6 hover-card-effect">
            <Link to={`/profile/${mvp.id}`} className="block">
              <div className="flex items-center space-x-4">
                <UserAvatar 
                  user={{
                    id: mvp.id,
                    avatar: mvp.avatar,
                    name: mvp.name
                  }}
                  size="lg"
                  linkDisabled={true}
                />
                <div>
                  <span className="text-xl font-bold hover:text-primary">
                    {mvp.name}
                  </span>
                  <p className="text-muted-foreground">{mvp.title}</p>
                </div>
              </div>
            </Link>
            <div className="mt-4 flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Trophy className="h-5 w-5 text-yellow-500" />
                <span>{mvp.contributions} contributions</span>
              </div>
              <a 
                href={mvp.githubUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-muted-foreground hover:text-foreground"
              >
                <Github className="h-5 w-5" />
              </a>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}