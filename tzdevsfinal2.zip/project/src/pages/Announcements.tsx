import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Bell, Calendar, Users, Rocket } from 'lucide-react';

const announcements = [
  {
    icon: Rocket,
    title: "New Platform Features",
    date: "March 20, 2024",
    content: "We're excited to announce new collaboration features...",
    category: "Platform Update"
  },
  {
    icon: Calendar,
    title: "Upcoming Hackathon",
    date: "March 19, 2024",
    content: "Join us for our quarterly community hackathon...",
    category: "Event"
  },
  {
    icon: Users,
    title: "Community Milestone",
    date: "March 18, 2024",
    content: "We've reached 1000 active members...",
    category: "Milestone"
  }
];

export function Announcements() {
  return (
    <div className="space-y-8">
      <section className="text-center">
        <h1 className="text-4xl font-bold">
          <span className="gradient-text">Announcements</span>
        </h1>
        <p className="mt-4 text-lg text-muted-foreground">
          Stay updated with the latest news and announcements
        </p>
      </section>

      <div className="space-y-6">
        {announcements.map((announcement, index) => (
          <Card key={index} className="p-6 hover-card-effect">
            <div className="flex items-start space-x-4">
              <div className="rounded-full bg-primary/10 p-3">
                <announcement.icon className="h-6 w-6 text-primary" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <span className="rounded-full bg-primary/10 px-3 py-1 text-sm text-primary">
                    {announcement.category}
                  </span>
                  <span className="text-sm text-muted-foreground">{announcement.date}</span>
                </div>
                <h3 className="mt-2 text-xl font-semibold">{announcement.title}</h3>
                <p className="mt-2 text-muted-foreground">{announcement.content}</p>
                <Button className="mt-4">Read More</Button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}