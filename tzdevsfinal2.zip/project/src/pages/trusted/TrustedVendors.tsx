import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select } from '@/components/ui/select';
import { Search, Building2, ShoppingBag, Code, Star } from 'lucide-react';

interface Vendor {
  id: string;
  name: string;
  logo: string;
  description: string;
  category: string[];
  rating: number;
  services: string[];
  products: string[];
  location: string;
  website: string;
}

const vendors: Vendor[] = [
  {
    id: '1',
    name: 'TechCorp Solutions',
    logo: 'https://images.unsplash.com/photo-1560179707-f14e90ef3623?w=100',
    description: 'Leading provider of IT solutions and hardware in Tanzania',
    category: ['Hardware', 'Software Development', 'IT Services'],
    rating: 4.8,
    services: ['Custom Software Development', 'IT Consulting', 'Cloud Solutions'],
    products: ['Laptops', 'Servers', 'Networking Equipment'],
    location: 'Dar es Salaam',
    website: 'https://techcorp.co.tz'
  },
  {
    id: '2',
    name: 'Digital Innovators',
    logo: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=100',
    description: 'Specialized in digital transformation and software solutions',
    category: ['Software Development', 'Digital Marketing', 'Training'],
    rating: 4.9,
    services: ['Web Development', 'Mobile Apps', 'Digital Marketing'],
    products: ['SaaS Solutions', 'E-commerce Platforms'],
    location: 'Arusha',
    website: 'https://digitalinnovators.co.tz'
  }
];

const categories = ['All', 'Hardware', 'Software Development', 'IT Services', 'Digital Marketing', 'Training'];

export function TrustedVendors() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  const filteredVendors = vendors.filter(vendor => {
    const matchesSearch = vendor.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         vendor.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || vendor.category.includes(selectedCategory);
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="space-y-8">
      <section className="text-center">
        <h1 className="text-4xl font-bold">
          <span className="gradient-text">Trusted Vendors</span>
        </h1>
        <p className="mt-4 text-lg text-muted-foreground">
          Verified companies and service providers in Tanzania
        </p>
      </section>

      <div className="flex flex-col space-y-4 md:flex-row md:space-y-0 md:space-x-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            className="pl-10"
            placeholder="Search vendors..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Select
          value={selectedCategory}
          onValueChange={setSelectedCategory}
        >
          {categories.map(category => (
            <option key={category} value={category}>{category}</option>
          ))}
        </Select>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {filteredVendors.map((vendor) => (
          <Card key={vendor.id} className="p-6">
            <div className="flex items-start space-x-4">
              <img
                src={vendor.logo}
                alt={vendor.name}
                className="h-16 w-16 rounded-lg object-cover"
              />
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h3 className="text-xl font-bold">{vendor.name}</h3>
                  <div className="flex items-center">
                    <Star className="h-4 w-4 text-yellow-400" />
                    <span className="ml-1">{vendor.rating}</span>
                  </div>
                </div>
                <p className="mt-2 text-muted-foreground">{vendor.description}</p>
                <div className="mt-4 flex flex-wrap gap-2">
                  {vendor.category.map((cat) => (
                    <span
                      key={cat}
                      className="rounded-full bg-primary/10 px-3 py-1 text-sm text-primary"
                    >
                      {cat}
                    </span>
                  ))}
                </div>
                <div className="mt-4 grid gap-4 md:grid-cols-2">
                  <div>
                    <h4 className="font-semibold flex items-center">
                      <Code className="mr-2 h-4 w-4" />
                      Services
                    </h4>
                    <ul className="mt-2 space-y-1 text-sm text-muted-foreground">
                      {vendor.services.map((service) => (
                        <li key={service}>{service}</li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold flex items-center">
                      <ShoppingBag className="mr-2 h-4 w-4" />
                      Products
                    </h4>
                    <ul className="mt-2 space-y-1 text-sm text-muted-foreground">
                      {vendor.products.map((product) => (
                        <li key={product}>{product}</li>
                      ))}
                    </ul>
                  </div>
                </div>
                <div className="mt-4 flex items-center justify-between">
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Building2 className="mr-2 h-4 w-4" />
                    {vendor.location}
                  </div>
                  <Button
                    as="a"
                    href={vendor.website}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    Visit Website
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}