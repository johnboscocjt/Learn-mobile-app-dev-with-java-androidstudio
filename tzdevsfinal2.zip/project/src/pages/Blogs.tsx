import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar } from '@/components/ui/avatar';

const blogs = [
  {
    title: "My Journey as a Developer in Tanzania",
    author: "Sarah Johnson",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100",
    date: "March 20, 2024",
    readTime: "8 min read",
    excerpt: "Sharing my experience and lessons learned while working as a developer in Tanzania...",
    tags: ["Career", "Personal Growth"]
  },
  {
    title: "Building a Tech Community in East Africa",
    author: "Michael Chen",
    avatar: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=100",
    date: "March 19, 2024",
    readTime: "6 min read",
    excerpt: "How we're fostering a vibrant tech ecosystem in East Africa...",
    tags: ["Community", "Tech Ecosystem"]
  }
];

export function Blogs() {
  return (
    <div className="space-y-8">
      <section className="text-center">
        <h1 className="text-4xl font-bold">
          <span className="gradient-text">Community Blogs</span>
        </h1>
        <p className="mt-4 text-lg text-muted-foreground">
          Discover insights and experiences from fellow developers
        </p>
        <Button className="btn-gradient mt-6">Start Writing</Button>
      </section>

      <div className="grid gap-6 md:grid-cols-2">
        {blogs.map((blog, index) => (
          <Card key={index} className="p-6 hover-card-effect">
            <div className="flex items-center space-x-4">
              <Avatar>
                <img src={blog.avatar} alt={blog.author} />
              </Avatar>
              <div>
                <h3 className="font-semibold">{blog.author}</h3>
                <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                  <span>{blog.date}</span>
                  <span>•</span>
                  <span>{blog.readTime}</span>
                </div>
              </div>
            </div>
            <h2 className="mt-4 text-xl font-bold">{blog.title}</h2>
            <p className="mt-2 text-muted-foreground">{blog.excerpt}</p>
            <div className="mt-4 flex flex-wrap gap-2">
              {blog.tags.map((tag) => (
                <span key={tag} className="rounded-full bg-primary/10 px-3 py-1 text-sm text-primary">
                  {tag}
                </span>
              ))}
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}