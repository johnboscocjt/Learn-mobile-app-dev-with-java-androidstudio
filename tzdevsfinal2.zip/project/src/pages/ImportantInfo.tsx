import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Info, Shield, FileText, AlertTriangle, HelpCircle, Book } from 'lucide-react';

const sections = [
  {
    icon: Info,
    title: "Community Guidelines",
    description: "Learn about our community's code of conduct and participation guidelines",
    action: "Read Guidelines"
  },
  {
    icon: Shield,
    title: "Privacy Policy",
    description: "Understanding how we protect and handle your information",
    action: "View Policy"
  },
  {
    icon: FileText,
    title: "Terms of Service",
    description: "Legal terms and conditions for using TzDevs",
    action: "Read Terms"
  },
  {
    icon: AlertTriangle,
    title: "Code of Ethics",
    description: "Our ethical principles and professional standards",
    action: "Learn More"
  },
  {
    icon: HelpCircle,
    title: "FAQ",
    description: "Frequently asked questions about our community",
    action: "View FAQ"
  },
  {
    icon: Book,
    title: "Documentation",
    description: "Detailed documentation about our platform",
    action: "Read Docs"
  }
];

export function ImportantInfo() {
  return (
    <div className="space-y-8">
      <section className="text-center">
        <h1 className="text-4xl font-bold">
          <span className="gradient-text">Important Information</span>
        </h1>
        <p className="mt-4 text-lg text-muted-foreground">
          Essential guidelines and information for our community
        </p>
      </section>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {sections.map((section, index) => (
          <Card key={index} className="p-6 hover-card-effect">
            <section.icon className="h-8 w-8 text-primary" />
            <h3 className="mt-4 text-xl font-semibold">{section.title}</h3>
            <p className="mt-2 text-muted-foreground">{section.description}</p>
            <Button className="mt-4 w-full">{section.action}</Button>
          </Card>
        ))}
      </div>
    </div>
  );
}