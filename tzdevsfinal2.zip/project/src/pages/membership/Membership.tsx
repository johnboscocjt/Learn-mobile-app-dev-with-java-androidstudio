import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Check, Star } from 'lucide-react';
import { motion } from 'framer-motion';

interface PlanFeature {
  name: string;
  included: boolean;
}

interface Plan {
  name: string;
  monthlyPrice: number;
  yearlyPrice: number;
  features: PlanFeature[];
  highlight?: boolean;
}

const plans: Plan[] = [
  {
    name: 'Basic',
    monthlyPrice: 9.99,
    yearlyPrice: 99.99,
    features: [
      { name: 'Access to all basic resources', included: true },
      { name: 'Join community discussions', included: true },
      { name: 'Basic project collaboration', included: true },
      { name: 'Limited marketplace access', included: true },
      { name: 'Email support', included: true },
      { name: 'Priority support', included: false },
      { name: 'Custom profile badge', included: false },
      { name: 'Advanced analytics', included: false }
    ]
  },
  {
    name: 'Pro',
    monthlyPrice: 19.99,
    yearlyPrice: 199.99,
    highlight: true,
    features: [
      { name: 'Access to all basic resources', included: true },
      { name: 'Join community discussions', included: true },
      { name: 'Advanced project collaboration', included: true },
      { name: 'Full marketplace access', included: true },
      { name: 'Priority email support', included: true },
      { name: 'Priority support', included: true },
      { name: 'Custom profile badge', included: true },
      { name: 'Advanced analytics', included: true }
    ]
  },
  {
    name: 'Enterprise',
    monthlyPrice: 49.99,
    yearlyPrice: 499.99,
    features: [
      { name: 'All Pro features', included: true },
      { name: 'Custom solutions', included: true },
      { name: 'Dedicated support', included: true },
      { name: 'Team management', included: true },
      { name: 'API access', included: true },
      { name: 'Custom integrations', included: true },
      { name: 'Advanced security', included: true },
      { name: 'SLA guarantee', included: true }
    ]
  }
];

export function Membership() {
  const [isYearly, setIsYearly] = useState(false);
  const [promoCode, setPromoCode] = useState('');

  return (
    <div className="space-y-8">
      <section className="text-center">
        <h1 className="text-4xl font-bold">
          <span className="gradient-text">Choose Your Plan</span>
        </h1>
        <p className="mt-4 text-lg text-muted-foreground">
          Get access to exclusive features and support the community
        </p>
      </section>

      <div className="flex justify-center space-x-4">
        <Button
          variant={isYearly ? 'outline' : 'default'}
          onClick={() => setIsYearly(false)}
        >
          Monthly
        </Button>
        <Button
          variant={isYearly ? 'default' : 'outline'}
          onClick={() => setIsYearly(true)}
        >
          Yearly (Save 20%)
        </Button>
      </div>

      <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
        {plans.map((plan) => (
          <motion.div
            key={plan.name}
            className="relative"
            whileHover={{ y: -10 }}
            initial={{ y: 0 }}
            transition={{ duration: 0.3 }}
          >
            <Card className={`p-6 ${plan.highlight ? 'border-primary' : ''}`}>
              {plan.highlight && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className="bg-primary text-primary-foreground px-4 py-1 rounded-full text-sm">
                    Most Popular
                  </span>
                </div>
              )}
              <div className="text-center">
                <h3 className="text-2xl font-bold">{plan.name}</h3>
                <div className="mt-4">
                  <span className="text-4xl font-bold">
                    ${isYearly ? plan.yearlyPrice : plan.monthlyPrice}
                  </span>
                  <span className="text-muted-foreground">
                    /{isYearly ? 'year' : 'month'}
                  </span>
                </div>
              </div>
              <div className="mt-6 space-y-4">
                {plan.features.map((feature, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <Check
                      className={`h-5 w-5 ${
                        feature.included ? 'text-primary' : 'text-muted-foreground'
                      }`}
                    />
                    <span
                      className={
                        feature.included ? '' : 'text-muted-foreground line-through'
                      }
                    >
                      {feature.name}
                    </span>
                  </div>
                ))}
              </div>
              <Button className="w-full mt-6">Choose {plan.name}</Button>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="mt-8 max-w-md mx-auto">
        <div className="flex space-x-2">
          <Input
            placeholder="Enter promo code"
            value={promoCode}
            onChange={(e) => setPromoCode(e.target.value)}
          />
          <Button variant="outline">Apply</Button>
        </div>
      </div>
    </div>
  );
}