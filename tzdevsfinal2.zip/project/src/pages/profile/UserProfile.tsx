import { useState } from 'react';
import { motion } from 'framer-motion';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { 
  User, Settings, Bookmark, Archive, PenTool, 
  BookOpen, Users, Map, Github, Twitter, 
  Linkedin, Globe, Edit
} from 'lucide-react';

interface TechStack {
  name: string;
  icon: string;
  experience: string;
}

interface UserProfile {
  id: string;
  username: string;
  name: string;
  avatar: string;
  bio: string;
  techStack: TechStack[];
  followers: number;
  following: number;
  location: string;
  joinDate: string;
  socialLinks: {
    github?: string;
    twitter?: string;
    linkedin?: string;
    website?: string;
  };
}

const dummyUser: UserProfile = {
  id: '1',
  username: 'johndoe',
  name: 'John Doe',
  avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200',
  bio: 'Full Stack Developer | Open Source Contributor | Tech Enthusiast',
  techStack: [
    { name: 'React', icon: '/icons/react.svg', experience: '3 years' },
    { name: 'Node.js', icon: '/icons/nodejs.svg', experience: '2 years' },
    { name: 'TypeScript', icon: '/icons/typescript.svg', experience: '2 years' }
  ],
  followers: 245,
  following: 180,
  location: 'Dar es Salaam, Tanzania',
  joinDate: 'January 2022',
  socialLinks: {
    github: 'https://github.com/johndoe',
    twitter: 'https://twitter.com/johndoe',
    linkedin: 'https://linkedin.com/in/johndoe',
    website: 'https://johndoe.dev'
  }
};

export function UserProfile() {
  const [activeTab, setActiveTab] = useState('posts');
  const [isEditing, setIsEditing] = useState(false);

  return (
    <div className="space-y-8">
      <Card className="p-6">
        <div className="flex flex-col items-center md:flex-row md:items-start md:space-x-6">
          <Avatar className="h-32 w-32">
            <img src={dummyUser.avatar} alt={dummyUser.name} />
          </Avatar>
          <div className="flex-1 text-center md:text-left">
            <div className="flex items-center justify-center md:justify-between">
              <div>
                <h1 className="text-3xl font-bold">{dummyUser.name}</h1>
                <p className="text-muted-foreground">@{dummyUser.username}</p>
              </div>
              <Button variant="outline" onClick={() => setIsEditing(!isEditing)}>
                <Edit className="mr-2 h-4 w-4" />
                Edit Profile
              </Button>
            </div>
            <p className="mt-4">{dummyUser.bio}</p>
            <div className="mt-4 flex flex-wrap items-center gap-4">
              <div className="flex items-center">
                <Users className="mr-2 h-4 w-4" />
                <span className="font-semibold">{dummyUser.followers}</span>
                <span className="ml-1 text-muted-foreground">Followers</span>
              </div>
              <div className="flex items-center">
                <Users className="mr-2 h-4 w-4" />
                <span className="font-semibold">{dummyUser.following}</span>
                <span className="ml-1 text-muted-foreground">Following</span>
              </div>
              <div className="flex items-center">
                <Map className="mr-2 h-4 w-4" />
                <span>{dummyUser.location}</span>
              </div>
            </div>
            <div className="mt-4 flex space-x-4">
              {dummyUser.socialLinks.github && (
                <a
                  href={dummyUser.socialLinks.github}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-muted-foreground hover:text-foreground"
                >
                  <Github className="h-5 w-5" />
                </a>
              )}
              {dummyUser.socialLinks.twitter && (
                <a
                  href={dummyUser.socialLinks.twitter}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-muted-foreground hover:text-foreground"
                >
                  <Twitter className="h-5 w-5" />
                </a>
              )}
              {dummyUser.socialLinks.linkedin && (
                <a
                  href={dummyUser.socialLinks.linkedin}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-muted-foreground hover:text-foreground"
                >
                  <Linkedin className="h-5 w-5" />
                </a>
              )}
              {dummyUser.socialLinks.website && (
                <a
                  href={dummyUser.socialLinks.website}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-muted-foreground hover:text-foreground"
                >
                  <Globe className="h-5 w-5" />
                </a>
              )}
            </div>
          </div>
        </div>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-4 lg:grid-cols-8">
          <TabsTrigger value="posts">Posts</TabsTrigger>
          <TabsTrigger value="techstack">Tech Stack</TabsTrigger>
          <TabsTrigger value="articles">Articles</TabsTrigger>
          <TabsTrigger value="blogs">Blogs</TabsTrigger>
          <TabsTrigger value="roadmap">Roadmap</TabsTrigger>
          <TabsTrigger value="bookmarks">Bookmarks</TabsTrigger>
          <TabsTrigger value="archive">Archive</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <div className="mt-6">
          <TabsContent value="techstack">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {dummyUser.techStack.map((tech) => (
                <motion.div
                  key={tech.name}
                  whileHover={{ scale: 1.05 }}
                  transition={{ duration: 0.2 }}
                >
                  <Card className="p-4">
                    <div className="flex items-center space-x-3">
                      <img src={tech.icon} alt={tech.name} className="h-8 w-8" />
                      <div>
                        <h3 className="font-semibold">{tech.name}</h3>
                        <p className="text-sm text-muted-foreground">{tech.experience}</p>
                      </div>
                    </div>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          {/* Add other tab contents here */}
        </div>
      </Tabs>
    </div>
  );
}