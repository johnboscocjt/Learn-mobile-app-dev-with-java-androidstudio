import { FeatureCard } from '@/components/cards/FeatureCard';
import { MessageSquare, Users, Calendar, Code, Target, Rocket } from 'lucide-react';
import { Button } from '@/components/ui/button';

const features = [
  {
    icon: MessageSquare,
    title: "Discussion Forums",
    description: "Engage in technical discussions and share knowledge"
  },
  {
    icon: Users,
    title: "Team Formation",
    description: "Find team members for your projects"
  },
  {
    icon: Calendar,
    title: "Events",
    description: "Join community events and meetups"
  },
  {
    icon: Code,
    title: "Code Reviews",
    description: "Get feedback on your code from peers"
  },
  {
    icon: Target,
    title: "Mentorship",
    description: "Connect with mentors and mentees"
  },
  {
    icon: Rocket,
    title: "Hackathons",
    description: "Participate in coding challenges and hackathons"
  }
];

export function Collaboration() {
  return (
    <div className="space-y-8">
      <section className="text-center">
        <h1 className="text-4xl font-bold">
          <span className="gradient-text">Collaboration Hub</span>
        </h1>
        <p className="mt-4 text-lg text-muted-foreground">
          Find opportunities to collaborate with other developers
        </p>
        <Button className="btn-gradient mt-6">Start Collaborating</Button>
      </section>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {features.map((feature, index) => (
          <FeatureCard key={index} {...feature} />
        ))}
      </div>
    </div>
  );
}