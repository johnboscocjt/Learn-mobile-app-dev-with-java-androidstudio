import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const articles = [
  {
    title: "Getting Started with Web Development in Tanzania",
    author: "John Doe",
    date: "2024-03-20",
    readTime: "5 min read",
    excerpt: "A comprehensive guide for aspiring web developers in Tanzania...",
    tags: ["Web Development", "Beginners"]
  },
  {
    title: "Building Scalable Applications with React",
    author: "Jane Smith",
    date: "2024-03-19",
    readTime: "8 min read",
    excerpt: "Learn best practices for building large-scale React applications...",
    tags: ["React", "Architecture"]
  }
];

export function Articles() {
  return (
    <div className="space-y-8">
      <section className="text-center">
        <h1 className="text-4xl font-bold">
          <span className="gradient-text">Technical Articles</span>
        </h1>
        <p className="mt-4 text-lg text-muted-foreground">
          Read and learn from the community's technical articles
        </p>
        <Button className="btn-gradient mt-6">Write an Article</Button>
      </section>

      <div className="grid gap-6 md:grid-cols-2">
        {articles.map((article, index) => (
          <Card key={index} className="p-6 hover-card-effect">
            <h3 className="text-xl font-semibold">{article.title}</h3>
            <div className="mt-2 flex flex-wrap gap-2">
              {article.tags.map((tag) => (
                <span key={tag} className="rounded-full bg-primary/10 px-3 py-1 text-sm text-primary">
                  {tag}
                </span>
              ))}
            </div>
            <p className="mt-4 text-muted-foreground">{article.excerpt}</p>
            <div className="mt-4 flex items-center justify-between text-sm">
              <span>{article.author}</span>
              <div className="flex items-center gap-2">
                <span>{article.date}</span>
                <span>•</span>
                <span>{article.readTime}</span>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}