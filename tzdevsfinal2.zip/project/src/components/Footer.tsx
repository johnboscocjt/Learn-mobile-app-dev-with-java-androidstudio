import { Link } from 'react-router-dom';
import { Code2, Github, Twitter, Linkedin } from 'lucide-react';

export function Footer() {
  return (
    <footer className="border-t bg-background">
      <div className="container py-12 md:py-16 lg:py-20">
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          <div>
            <Link to="/" className="flex items-center space-x-2">
              <Code2 className="h-6 w-6" />
              <span className="font-bold">TzDevs</span>
            </Link>
            <p className="mt-4 text-sm text-muted-foreground">
              Uniting developers across Tanzania to build a stronger tech community.
            </p>
          </div>

          <div>
            <h3 className="font-semibold">Community</h3>
            <ul className="mt-4 space-y-2 text-sm">
              <li><Link to="/community">Members</Link></li>
              <li><Link to="/collaboration">Discussions</Link></li>
              <li><Link to="/projects">Projects</Link></li>
              <li><Link to="/mvp">MVP Program</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold">Resources</h3>
            <ul className="mt-4 space-y-2 text-sm">
              <li><Link to="/resources">Learning</Link></li>
              <li><Link to="/articles">Articles</Link></li>
              <li><Link to="/blogs">Blogs</Link></li>
              <li><Link to="/important-info">Guidelines</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold">Connect</h3>
            <div className="mt-4 flex space-x-4">
              <a href="https://github.com/tzdevs" className="text-muted-foreground hover:text-foreground">
                <Github className="h-5 w-5" />
              </a>
              <a href="https://twitter.com/tzdevs" className="text-muted-foreground hover:text-foreground">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="https://linkedin.com/company/tzdevs" className="text-muted-foreground hover:text-foreground">
                <Linkedin className="h-5 w-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="mt-12 border-t pt-8 text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} TzDevs. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}