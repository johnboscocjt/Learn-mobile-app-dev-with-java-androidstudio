import { useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { Post } from '@/types/post';
import { dummyPosts } from '@/data/dummy-posts';
import { PostCard } from '@/components/posts/PostCard';
import { PostSkeleton } from '@/components/posts/PostSkeleton';

export function InfiniteScroll() {
  const [posts, setPosts] = useState<Post[]>(dummyPosts);
  const [loading, setLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const loader = useRef(null);

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  return (
    <motion.div 
      className="space-y-6"
      variants={container}
      initial="hidden"
      animate="show"
    >
      {posts.map((post) => (
        <motion.div key={post.id} variants={item}>
          <PostCard post={post} />
        </motion.div>
      ))}
      
      {loading && (
        <div className="space-y-4">
          {[...Array(2)].map((_, i) => (
            <PostSkeleton key={i} />
          ))}
        </div>
      )}
      
      <div ref={loader} className="h-4" />
    </motion.div>
  );
}