import { Link, useLocation } from 'react-router-dom';
import { 
  Code2, Users, BookOpen, MessageSquare, Github, 
  Newspaper, PenTool, FolderGit2, Trophy, Bell,
  FileText, Layout, ShoppingBag, MessagesSquare,
  Youtube, Map, Mail, Home, Lightbulb, Megaphone,
  BookMarked, Info, LayoutDashboard, CreditCard,
  Building2
} from 'lucide-react';
import { NavigationMenu, NavigationMenuList, NavigationMenuItem, NavigationMenuTrigger, NavigationMenuContent } from '@/components/ui/navigation-menu';
import { Button } from '@/components/ui/button';
import { Avatar } from '@/components/ui/avatar';

export function Navbar() {
  const location = useLocation();

  return (
    <nav className="border-b bg-background">
      <div className="container flex h-16 items-center">
        <Link to="/" className="flex items-center space-x-2">
          <Code2 className="h-6 w-6" />
          <span className="font-bold">TzDevs</span>
        </Link>

        <NavigationMenu className="mx-6">
          <NavigationMenuList>
            <NavigationMenuItem>
              <NavigationMenuTrigger>Community</NavigationMenuTrigger>
              <NavigationMenuContent>
                <div className="grid gap-3 p-4 md:w-[400px] lg:w-[500px] lg:grid-cols-[.75fr_1fr]">
                  <Link to="/community" className="flex items-center space-x-2 p-2 hover:bg-accent">
                    <Users className="h-5 w-5" />
                    <span>Members</span>
                  </Link>
                  <Link to="/chat" className="flex items-center space-x-2 p-2 hover:bg-accent">
                    <MessagesSquare className="h-5 w-5" />
                    <span>Chat Rooms</span>
                  </Link>
                  <Link to="/collaboration" className="flex items-center space-x-2 p-2 hover:bg-accent">
                    <MessageSquare className="h-5 w-5" />
                    <span>Discussions</span>
                  </Link>
                  <Link to="/projects" className="flex items-center space-x-2 p-2 hover:bg-accent">
                    <FolderGit2 className="h-5 w-5" />
                    <span>Projects</span>
                  </Link>
                  <Link to="/mvp" className="flex items-center space-x-2 p-2 hover:bg-accent">
                    <Trophy className="h-5 w-5" />
                    <span>MVP Program</span>
                  </Link>
                </div>
              </NavigationMenuContent>
            </NavigationMenuItem>

            <NavigationMenuItem>
              <NavigationMenuTrigger>Resources</NavigationMenuTrigger>
              <NavigationMenuContent>
                <div className="grid gap-3 p-4 md:w-[400px] lg:w-[500px] lg:grid-cols-[.75fr_1fr]">
                  <Link to="/resources" className="flex items-center space-x-2 p-2 hover:bg-accent">
                    <BookOpen className="h-5 w-5" />
                    <span>Learning</span>
                  </Link>
                  <Link to="/articles" className="flex items-center space-x-2 p-2 hover:bg-accent">
                    <Newspaper className="h-5 w-5" />
                    <span>Articles</span>
                  </Link>
                  <Link to="/blogs" className="flex items-center space-x-2 p-2 hover:bg-accent">
                    <PenTool className="h-5 w-5" />
                    <span>Blogs</span>
                  </Link>
                  <Link to="/marketplace" className="flex items-center space-x-2 p-2 hover:bg-accent">
                    <ShoppingBag className="h-5 w-5" />
                    <span>Marketplace</span>
                  </Link>
                  <Link to="/trusted-vendors" className="flex items-center space-x-2 p-2 hover:bg-accent">
                    <Building2 className="h-5 w-5" />
                    <span>Trusted Vendors</span>
                  </Link>
                </div>
              </NavigationMenuContent>
            </NavigationMenuItem>

            <NavigationMenuItem>
              <NavigationMenuTrigger>More</NavigationMenuTrigger>
              <NavigationMenuContent>
                <div className="grid gap-3 p-4 md:w-[400px] lg:w-[500px] lg:grid-cols-[.75fr_1fr]">
                  <Link to="/important-info" className="flex items-center space-x-2 p-2 hover:bg-accent">
                    <Info className="h-5 w-5" />
                    <span>Guidelines</span>
                  </Link>
                  <Link to="/announcements" className="flex items-center space-x-2 p-2 hover:bg-accent">
                    <Bell className="h-5 w-5" />
                    <span>Announcements</span>
                  </Link>
                  <Link to="/billboard" className="flex items-center space-x-2 p-2 hover:bg-accent">
                    <Layout className="h-5 w-5" />
                    <span>Billboard</span>
                  </Link>
                  <Link to="/membership" className="flex items-center space-x-2 p-2 hover:bg-accent">
                    <CreditCard className="h-5 w-5" />
                    <span>Membership</span>
                  </Link>
                </div>
              </NavigationMenuContent>
            </NavigationMenuItem>
          </NavigationMenuList>
        </NavigationMenu>

        <div className="ml-auto flex items-center space-x-4">
          <Button variant="ghost" size="icon">
            <Bell className="h-5 w-5" />
          </Button>
          <Link to="/profile/johndoe">
            <Avatar>
              <img src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100" alt="Profile" />
            </Avatar>
          </Link>
        </div>
      </div>
    </nav>
  );
}