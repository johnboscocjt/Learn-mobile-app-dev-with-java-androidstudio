import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { FallingStars } from '@/components/ui/falling-stars';
import { SnowEffect } from '@/components/ui/snow-effect';
import { Home } from '@/pages/Home';
import { Community } from '@/pages/Community';
import { Resources } from '@/pages/Resources';
import { Articles } from '@/pages/Articles';
import { Blogs } from '@/pages/Blogs';
import { Projects } from '@/pages/Projects';
import { Collaboration } from '@/pages/Collaboration';
import { MVP } from '@/pages/MVP';
import { ImportantInfo } from '@/pages/ImportantInfo';
import { Announcements } from '@/pages/Announcements';
import { Billboard } from '@/pages/Billboard';
import { ChatRooms } from '@/pages/chat/ChatRooms';
import { Marketplace } from '@/pages/marketplace/Marketplace';
import { Membership } from '@/pages/membership/Membership';
import { TrustedVendors } from '@/pages/trusted/TrustedVendors';
import { UserProfile } from '@/pages/profile/UserProfile';

export default function App() {
  return (
    <Router>
      <div className="relative min-h-screen">
        <FallingStars />
        <SnowEffect />
        <div className="relative z-10">
          <Navbar />
          <main className="container mx-auto px-4 py-8">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/community" element={<Community />} />
              <Route path="/resources" element={<Resources />} />
              <Route path="/articles" element={<Articles />} />
              <Route path="/blogs" element={<Blogs />} />
              <Route path="/projects" element={<Projects />} />
              <Route path="/collaboration" element={<Collaboration />} />
              <Route path="/mvp" element={<MVP />} />
              <Route path="/important-info" element={<ImportantInfo />} />
              <Route path="/announcements" element={<Announcements />} />
              <Route path="/billboard" element={<Billboard />} />
              <Route path="/chat" element={<ChatRooms />} />
              <Route path="/marketplace" element={<Marketplace />} />
              <Route path="/membership" element={<Membership />} />
              <Route path="/trusted-vendors" element={<TrustedVendors />} />
              <Route path="/profile/:username" element={<UserProfile />} />
            </Routes>
          </main>
          <Footer />
        </div>
      </div>
    </Router>
  );
}